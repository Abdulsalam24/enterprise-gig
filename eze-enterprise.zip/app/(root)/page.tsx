import Home from "@/templates/home";

export default function HomePage() {
  return <Home />;
}
